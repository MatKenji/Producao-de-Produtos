package backend;

public interface Imprimivel {
    void imprime();
    
}
